package com.example.myapplication4;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tvInscription, tvSize;
    final int menu_bold = 1;
    final int menu_italic = 2;
    final int menu_bold_italic = 3;
    final int menu_normal = 4;
    final int menu_size_20 = 5;
    final int menu_size_28 = 6;
    final int menu_size_31 = 7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       tvInscription = (TextView) findViewById(R.id.tv);
       tvSize = (TextView) findViewById(R.id.tv_size);
       registerForContextMenu(tvInscription);
       registerForContextMenu(tvSize);
    }
    
    @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
         int menuinfo = v.getId();
             if (menuinfo == R.id.tv) {
                 menu.add(0, menu_bold, 0, "Полужирный");
                 menu.add(0, menu_italic, 0, "Курсив");
                 menu.add(0, menu_bold_italic, 0, "Полужирный курсив");
                 menu.add(0, menu_normal, 0, "Обычный");
             } else if (menuinfo == R.id.tv_size)
             {
                menu.add(0, menu_size_20,0, "20");
                menu.add(0, menu_size_28,0, "28");
                menu.add(0, menu_size_31,0, "31");
         }
        super.onCreateContextMenu(menu, v, menuInfo);
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case menu_bold:
             tvInscription.setTypeface(null, Typeface.BOLD);
             tvInscription.setText("Полужирный");
             break;
            case menu_bold_italic:
              tvInscription.setTypeface(null, Typeface.BOLD_ITALIC);
              tvInscription.setText("Полужирный курсив");
              break;
            case menu_italic:
                tvInscription.setTypeface(null, Typeface.ITALIC);
                tvInscription.setText("Курсив");
                break;
            case menu_normal:
                tvInscription.setTypeface(null, Typeface.NORMAL);
                tvInscription.setText("Обычный");
                break;
            case menu_size_20:
                tvSize.setTextSize(20);
                tvSize.setText("Размер 20");
                break;
            case menu_size_28:
                tvSize.setTextSize(28);
                tvSize.setText("Размер 28");
                break;
            case menu_size_31:
                tvSize.setTextSize(31);
                tvSize.setText("Размер 31");
                break;
        }

        return super.onContextItemSelected(item);
    }
}