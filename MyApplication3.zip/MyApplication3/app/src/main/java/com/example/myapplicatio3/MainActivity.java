
package com.example.myapplicatio3;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreatePanelMenu(int featureId, @NonNull Menu menu) {
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        TextView infoTextView = (TextView) findViewById(R.id.textView);

        switch (id) {
            case R.id.action_os:
                infoTextView.setText("Операционные системы и сети");
                return true;
            case R.id.action_web:
                infoTextView.setText("WEB-программирование");
                return true;
            case R.id.action_java:
                infoTextView.setText("Мобильное программирование");
                return true;
            case R.id.action_database:
                infoTextView.setText("Базы данных");
                return true;
            case R.id.action_settings:
                Intent intent = new Intent(MainActivity.this, Settings.class);
                startActivities(new Intent[]{intent});
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}