package com.example.myapplication5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText mE1, mE2;
    TextView mResult;
    Button mB1, mB2, mB3, mB4;
    String mCount = " ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mE1 = (EditText) findViewById(R.id.et1);
        mE2 = (EditText) findViewById(R.id.et2);
        mResult = (TextView) findViewById(R.id.result);
        mB1 = (Button) findViewById(R.id.plus);
        mB2 = (Button) findViewById(R.id.minus);
        mB3 = (Button) findViewById(R.id.multiply);
        mB4 = (Button) findViewById(R.id.divide);

        mB1.setOnClickListener(this);
        mB2.setOnClickListener(this);
        mB3.setOnClickListener(this);
        mB4.setOnClickListener(this);
    }
        @Override
        public void onClick(View v) {
            Double value1 = null;
            Double value2 = null;
            double result = 0;
            try {

            value1 = Double.parseDouble(mE1.getText().toString());
            value2 = Double.parseDouble(mE2.getText().toString());
            
                int menuinfo = v.getId();
                if (menuinfo == R.id.plus) {
                    mCount = "+";
                    result = value1 + value2;
                }
                mResult.setText(value1 + " " + mCount + " " + value2 + " = " + result);

                    if (menuinfo == R.id.minus) {
                    mCount = "-";
                    result = value1 - value2;
                    }
                mResult.setText(value1 + " " + mCount + " " + value2 + " = " + result);

                        if (menuinfo == R.id.multiply) {
                    mCount = "*";
                    result = value1 * value2;
                        }
                mResult.setText(value1 + " " + mCount + " " + value2 + " = " + result);

                            if (menuinfo == R.id.divide) {
                    mCount = "/";
                    result = value1 / value2;
                            }
                mResult.setText(value1 + " " + mCount + " " + value2 + " = " + result);


        } catch (NumberFormatException e) {
                if ((value1 == null) || (value2 == null)) {
                    Toast.makeText(this, "Введите числа", Toast.LENGTH_LONG).show();
                }

            }
       }
    }
