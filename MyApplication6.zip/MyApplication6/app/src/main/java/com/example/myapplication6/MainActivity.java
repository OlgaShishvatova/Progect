package com.example.myapplication6;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{
LinearLayout llMain;
RadioGroup rgGravity;
EditText etName;
Button btnCreate, btnClear;
int wrap_content = ViewGroup.LayoutParams.WRAP_CONTENT;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



     llMain = (LinearLayout) findViewById(R.id.llMain);
     rgGravity = (RadioGroup) findViewById(R.id.rgGravity);
     etName = (EditText) findViewById(R.id.etName);
     btnCreate = (Button) findViewById(R.id.btnCreate);
     btnClear = (Button) findViewById(R.id.btnClear);

     btnCreate.setOnClickListener(this);
     btnClear.setOnClickListener(this);
    }
    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        int menuinfo = v.getId();

            if (menuinfo == R.id.btnCreate) {
                LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(wrap_content, wrap_content);
                int btnGravity = Gravity.LEFT;
                int idRg = rgGravity.getCheckedRadioButtonId();
                if (idRg == R.id.rbLeft) {
                    btnGravity = Gravity.LEFT;
                }
                if (idRg == R.id.rbCenter) {
                    btnGravity = Gravity.CENTER;
                }
                if (idRg == R.id.rbRight) {
                    btnGravity = Gravity.RIGHT;
                }
                lParams.gravity = btnGravity;
                Button btnNew = new Button(this);
                btnNew.setText(etName.getText().toString());
                llMain.addView(btnNew, lParams);
            }
            if (menuinfo == R.id.btnClear) {
                llMain.removeAllViews();
                Toast.makeText(this, "Удалено", Toast.LENGTH_LONG).show();

        }

    }
}